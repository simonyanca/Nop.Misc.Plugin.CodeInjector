1. 'Nop.Plugin.Misc.CodeInjector' directory contains source code.
2. 'Misc.CodeInjector' contains binaries. Just drop it into \Plugins directory on your server.